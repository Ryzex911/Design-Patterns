﻿using AdapterPattern.Interfaces;
using AdapterPattern.Turkeys;
using AdapterPattern.Geese;
using System;

namespace AdapterPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create a duck
            MallardDuck duck = new MallardDuck();

            // Create a turkey
            WildTurkey turkey = new WildTurkey();

            // Create a goose
            CanadaGoose goose = new CanadaGoose();

            // Adapt Turkey to Duck
            Duck turkeyAdapter = new TurkeyAdapter(turkey);

            // Adapt Goose to Duck
            Duck gooseAdapter = new GooseAdapter(goose);


            Console.WriteLine("The Turkey says...");
            turkey.Gobble();
            turkey.Fly();


            Console.WriteLine("\nThe Duck says...");
            TestDuck(duck);


            Console.WriteLine("\nThe TurkeyAdapter says...");
            TestDuck(turkeyAdapter);


            Console.WriteLine("\nThe Goose says...");
            goose.Honk();
            goose.Fly();


            Console.WriteLine("\nThe GooseAdapter says...");
            TestDuck(gooseAdapter);


            Console.ReadLine();
        }


        static void TestDuck(Duck duck)
        {
            duck.Quack();
            duck.Fly();
        }
    }
}